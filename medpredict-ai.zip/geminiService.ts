
import { GoogleGenAI } from "@google/genai";
import { PredictionResult } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getMotivationalMessage = async (prediction: PredictionResult): Promise<string> => {
  const riskLabel = prediction.riskScore > 0.6 ? "High" : prediction.riskScore > 0.3 ? "Moderate" : "Low";
  
  const prompt = `You are a supportive health assistant. 
  The user has a ${riskLabel} risk of missing their next medication dose (Risk Score: ${Math.round(prediction.riskScore * 100)}%). 
  Key reasons: ${prediction.features.map(f => `${f.name}: ${f.value}`).join(', ')}.
  Provide a short, 1-2 sentence motivational and supportive message to encourage them to stay on track. 
  Don't be clinical; be empathetic and encouraging.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Every dose counts towards your health journey. You've got this!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Staying consistent with your medicine is the best way to feel your best. We're here to help!";
  }
};
