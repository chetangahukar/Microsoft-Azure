
import { Medication, DoseLog, DoseStatus } from './types';

const KEYS = {
  MEDS: 'medpredict_meds',
  LOGS: 'medpredict_logs'
};

export const Storage = {
  getMedications: (): Medication[] => {
    const data = localStorage.getItem(KEYS.MEDS);
    return data ? JSON.parse(data) : [];
  },

  saveMedication: (med: Medication) => {
    const meds = Storage.getMedications();
    meds.push(med);
    localStorage.setItem(KEYS.MEDS, JSON.stringify(meds));
  },

  getLogs: (): DoseLog[] => {
    const data = localStorage.getItem(KEYS.LOGS);
    return data ? JSON.parse(data) : [];
  },

  saveLog: (log: DoseLog) => {
    const logs = Storage.getLogs();
    const existingIndex = logs.findIndex(l => l.id === log.id);
    if (existingIndex >= 0) {
      logs[existingIndex] = log;
    } else {
      logs.push(log);
    }
    localStorage.setItem(KEYS.LOGS, JSON.stringify(logs));
  },

  seedInitialData: () => {
    if (Storage.getMedications().length === 0) {
      const initialMed: Medication = {
        id: '1',
        name: 'Lisinopril',
        dosage: '10mg',
        frequency: 1,
        reminderTimes: ['08:00'],
        startDate: new Date().toISOString()
      };
      Storage.saveMedication(initialMed);
      
      // Seed some history for the ML to work with
      const now = new Date();
      for (let i = 1; i <= 7; i++) {
        const scheduled = new Date(now);
        scheduled.setDate(now.getDate() - i);
        scheduled.setHours(8, 0, 0, 0);
        
        Storage.saveLog({
          id: `seed-${i}`,
          medicationId: '1',
          scheduledTime: scheduled.toISOString(),
          recordedTime: i % 4 === 0 ? undefined : new Date(scheduled.getTime() + (Math.random() * 60 * 60000)).toISOString(),
          status: i % 4 === 0 ? DoseStatus.MISSED : DoseStatus.TAKEN,
          delayMinutes: i % 4 === 0 ? undefined : Math.floor(Math.random() * 45)
        });
      }
    }
  }
};
