
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib

def generate_synthetic_data(n_samples=1000):
    np.random.seed(42)
    
    # Features
    missed_doses_7d = np.random.randint(0, 8, n_samples)
    avg_delay_mins = np.random.uniform(0, 120, n_samples)
    doses_per_day = np.random.randint(1, 5, n_samples)
    is_complex_schedule = (doses_per_day > 2).astype(int)
    
    # Ground truth (risk)
    # Probability of missing next dose based on history
    logit = -2.0 + 0.8 * missed_doses_7d + 0.02 * avg_delay_mins + 0.5 * is_complex_schedule
    prob = 1 / (1 + np.exp(-logit))
    y = (np.random.rand(n_samples) < prob).astype(int)
    
    df = pd.DataFrame({
        'missed_doses_7d': missed_doses_7d,
        'avg_delay_mins': avg_delay_mins,
        'doses_per_day': doses_per_day,
        'is_complex_schedule': is_complex_schedule,
        'target_missed': y
    })
    return df

def train_and_save():
    print("Generating synthetic dataset...")
    data = generate_synthetic_data()
    
    X = data.drop('target_missed', axis=1)
    y = data['target_missed']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print("Training Random Forest Classifier...")
    model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
    model.fit(X_train, y_train)
    
    accuracy = model.score(X_test, y_test)
    print(f"Model Accuracy: {accuracy:.2f}")
    
    # Feature Importance
    importances = model.feature_importances_
    for i, f in enumerate(X.columns):
        print(f"Feature '{f}': {importances[i]:.4f}")
    
    joblib.dump(model, "adherence_model.pkl")
    print("Model saved as adherence_model.pkl")

if __name__ == "__main__":
    train_and_save()
