
from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
import sqlite3
import joblib
import pandas as pd
from datetime import datetime

app = FastAPI(title="MedPredict AI API")

# Load model
try:
    model = joblib.load("adherence_model.pkl")
except:
    model = None

class Medication(BaseModel):
    name: str
    dosage: str
    frequency: int
    reminder_times: List[str]

class DoseUpdate(BaseModel):
    medication_id: int
    status: str # 'TAKEN' | 'MISSED'
    delay_minutes: Optional[int] = 0

@app.on_event("startup")
def setup_db():
    conn = sqlite3.connect("meds.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS medications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            dosage TEXT,
            frequency INTEGER
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            med_id INTEGER,
            status TEXT,
            delay_minutes INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

@app.get("/prediction/{user_id}")
async def get_prediction(user_id: int):
    if not model:
        raise HTTPException(status_code=500, detail="ML model not loaded")
    
    # Query database for features
    # features = get_features_for_user(user_id)
    # mock_features = [[2, 15.5, 3, 1]] # missed_7d, avg_delay, doses_pd, complexity
    
    # risk_prob = model.predict_proba(mock_features)[0][1]
    return {"risk_score": 0.45, "recommendation": "Maintain schedule."}

@app.post("/medications")
async def add_medication(med: Medication):
    conn = sqlite3.connect("meds.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO medications (name, dosage, frequency) VALUES (?, ?, ?)", 
                   (med.name, med.dosage, med.frequency))
    conn.commit()
    return {"status": "success"}

@app.post("/log")
async def log_dose(update: DoseUpdate):
    conn = sqlite3.connect("meds.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO logs (med_id, status, delay_minutes) VALUES (?, ?, ?)",
                   (update.medication_id, update.status, update.delay_minutes))
    conn.commit()
    return {"status": "success"}
