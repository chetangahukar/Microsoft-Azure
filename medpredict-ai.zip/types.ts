
export enum DoseStatus {
  TAKEN = 'TAKEN',
  MISSED = 'MISSED',
  PENDING = 'PENDING'
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: number; // times per day
  reminderTimes: string[]; // HH:mm format
  startDate: string;
}

export interface DoseLog {
  id: string;
  medicationId: string;
  scheduledTime: string; // ISO String
  recordedTime?: string; // ISO String
  status: DoseStatus;
  delayMinutes?: number;
}

export interface PredictionResult {
  riskScore: number; // 0 to 1
  features: {
    name: string;
    impact: number; // -1 to 1 (negative reduces risk, positive increases it)
    value: string | number;
  }[];
  explanation: string;
  recommendation: string;
}

export interface UserStats {
  missedLast7Days: number;
  avgDelayMins: number;
  totalDoses: number;
  adherenceRate: number;
}
