
import { DoseLog, DoseStatus, Medication, PredictionResult } from './types';

/**
 * Simulates a Random Forest Classifier's probability output and feature importance.
 * In a real production environment, this would call the FastAPI /predict endpoint.
 */
export const predictAdherence = (
  meds: Medication[],
  logs: DoseLog[]
): PredictionResult => {
  const last7Days = new Date();
  last7Days.setDate(last7Days.getDate() - 7);

  const recentLogs = logs.filter(l => new Date(l.scheduledTime) > last7Days);
  const missedCount = recentLogs.filter(l => l.status === DoseStatus.MISSED).length;
  const takenLogs = recentLogs.filter(l => l.status === DoseStatus.TAKEN);
  
  const avgDelay = takenLogs.length > 0 
    ? takenLogs.reduce((acc, curr) => acc + (curr.delayMinutes || 0), 0) / takenLogs.length
    : 0;

  const scheduleComplexity = meds.reduce((acc, m) => acc + m.frequency, 0);

  // Heuristic Simulation of Random Forest Logic
  // Weights (learned by our "model")
  const W_MISSED = 0.12;
  const W_DELAY = 0.005;
  const W_COMPLEXITY = 0.05;

  let score = 0.1; // Base risk
  score += missedCount * W_MISSED;
  score += (avgDelay / 10) * W_DELAY;
  score += (scheduleComplexity - 1) * W_COMPLEXITY;

  // Clip between 0.05 and 0.95
  const finalRisk = Math.min(Math.max(score, 0.05), 0.95);

  const features = [
    { name: 'Recent Misses', value: missedCount, impact: missedCount > 1 ? 0.4 : -0.2 },
    { name: 'Response Lag', value: `${Math.round(avgDelay)}m`, impact: avgDelay > 30 ? 0.3 : -0.1 },
    { name: 'Plan Complexity', value: `${scheduleComplexity} doses/day`, impact: scheduleComplexity > 2 ? 0.2 : -0.1 }
  ];

  let explanation = '';
  if (finalRisk > 0.6) {
    explanation = "Your risk level is HIGH because you've missed several recent doses and have a relatively complex medication schedule.";
  } else if (finalRisk > 0.3) {
    explanation = "Your risk level is MODERATE. Consistency is key, try to minimize the delay in responding to reminders.";
  } else {
    explanation = "Your risk level is LOW. Excellent work maintaining your schedule!";
  }

  return {
    riskScore: finalRisk,
    features,
    explanation,
    recommendation: finalRisk > 0.5 
      ? "We've enabled adaptive reminders: you'll receive notifications 10 minutes earlier and with supportive messages."
      : "Standard reminder protocol active."
  };
};
