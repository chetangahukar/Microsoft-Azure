
import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Bell, CheckCircle, XCircle, Brain, AlertTriangle, Activity, History, Info, ChevronRight } from 'lucide-react';
import { Storage } from './store';
import { Medication, DoseLog, DoseStatus, PredictionResult } from './types';
import { predictAdherence } from './mlService';
import { getMotivationalMessage } from './geminiService';

// Initialize data
Storage.seedInitialData();

const App: React.FC = () => {
  const [medications, setMedications] = useState<Medication[]>(Storage.getMedications());
  const [logs, setLogs] = useState<DoseLog[]>(Storage.getLogs());
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [motivation, setMotivation] = useState<string>('Loading personalized support...');
  const [isAddingMed, setIsAddingMed] = useState(false);
  const [newMed, setNewMed] = useState({ name: '', dosage: '', frequency: 1 });

  // Compute prediction whenever data changes
  useEffect(() => {
    const result = predictAdherence(medications, logs);
    setPrediction(result);
  }, [medications, logs]);

  // Fetch AI motivation when prediction changes
  useEffect(() => {
    if (prediction) {
      getMotivationalMessage(prediction).then(setMotivation);
    }
  }, [prediction]);

  const handleMarkDose = (logId: string, status: DoseStatus) => {
    const existingLog = logs.find(l => l.id === logId);
    if (!existingLog) return;

    const updatedLog: DoseLog = {
      ...existingLog,
      status,
      recordedTime: new Date().toISOString(),
      delayMinutes: status === DoseStatus.TAKEN 
        ? Math.max(0, Math.floor((new Date().getTime() - new Date(existingLog.scheduledTime).getTime()) / 60000))
        : undefined
    };

    Storage.saveLog(updatedLog);
    setLogs(Storage.getLogs());
  };

  const handleAddMedication = (e: React.FormEvent) => {
    e.preventDefault();
    const med: Medication = {
      id: Date.now().toString(),
      name: newMed.name,
      dosage: newMed.dosage,
      frequency: newMed.frequency,
      reminderTimes: ['09:00'], // Default simplified
      startDate: new Date().toISOString()
    };
    Storage.saveMedication(med);
    setMedications(Storage.getMedications());
    setIsAddingMed(false);
    setNewMed({ name: '', dosage: '', frequency: 1 });
  };

  const upcomingDoses = useMemo(() => {
    return medications.flatMap(m => {
      // Find today's logs for this med
      const today = new Date();
      return m.reminderTimes.map(time => {
        const [hh, mm] = time.split(':');
        const scheduled = new Date(today);
        scheduled.setHours(parseInt(hh), parseInt(mm), 0, 0);
        
        // Find if we already have a log for this specific slot
        const log = logs.find(l => 
          l.medicationId === m.id && 
          new Date(l.scheduledTime).toDateString() === scheduled.toDateString() &&
          new Date(l.scheduledTime).getHours() === scheduled.getHours()
        );

        if (log) return log;

        // If no log, create a "virtual" pending log
        const newLog: DoseLog = {
          id: `virtual-${m.id}-${scheduled.getTime()}`,
          medicationId: m.id,
          scheduledTime: scheduled.toISOString(),
          status: DoseStatus.PENDING
        };
        return newLog;
      });
    }).sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
  }, [medications, logs]);

  const riskColor = prediction?.riskScore && prediction.riskScore > 0.6 
    ? 'text-rose-600 bg-rose-50 border-rose-200' 
    : prediction?.riskScore && prediction.riskScore > 0.3 
      ? 'text-amber-600 bg-amber-50 border-amber-200' 
      : 'text-emerald-600 bg-emerald-50 border-emerald-200';

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 px-4 py-4 md:px-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-indigo-600 p-2 rounded-xl">
            <Activity className="text-white w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-slate-800">MedPredict<span className="text-indigo-600">AI</span></h1>
        </div>
        <button 
          onClick={() => setIsAddingMed(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-2 transition-all shadow-lg shadow-indigo-100"
        >
          <Plus className="w-4 h-4" /> Add Med
        </button>
      </header>

      <main className="max-w-4xl mx-auto p-4 md:p-8 space-y-8">
        
        {/* Adherence Risk Dashboard */}
        <section className={`rounded-2xl border p-6 transition-all ${riskColor}`}>
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <Brain className="w-6 h-6" />
              <h2 className="text-lg font-bold">Adherence Risk Predictor</h2>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-3xl font-black">{(prediction?.riskScore || 0 * 100).toFixed(0)}%</span>
              <span className="text-xs uppercase tracking-wider font-bold opacity-80">Risk Score</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm font-medium mb-3 italic">"{motivation}"</p>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Info className="w-4 h-4 opacity-70" />
                  <p>{prediction?.explanation}</p>
                </div>
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <AlertTriangle className="w-4 h-4 opacity-70" />
                  <p>{prediction?.recommendation}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white/50 rounded-xl p-4 border border-current border-opacity-10">
              <h3 className="text-xs uppercase font-bold mb-3 opacity-60">Explainable AI: Feature Importance</h3>
              <div className="space-y-3">
                {prediction?.features.map((f, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-600">{f.name}</span>
                    <div className="flex items-center gap-3 flex-1 px-4">
                       <div className="h-1.5 bg-slate-200 rounded-full flex-1 overflow-hidden">
                          <div 
                            className={`h-full ${f.impact > 0 ? 'bg-rose-400' : 'bg-emerald-400'}`} 
                            style={{ width: `${Math.abs(f.impact) * 100}%`, marginLeft: f.impact < 0 ? '0' : '50%' }}
                          />
                       </div>
                    </div>
                    <span className="font-bold text-slate-800 w-12 text-right">{f.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Today's Schedule */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-500" /> Today's Reminders
            </h2>
            <span className="text-xs text-slate-500 bg-slate-200 px-2 py-1 rounded-full font-medium">
              {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {upcomingDoses.map((dose) => {
              const med = medications.find(m => m.id === dose.medicationId);
              const isTaken = dose.status === DoseStatus.TAKEN;
              const isMissed = dose.status === DoseStatus.MISSED;
              const isPending = dose.status === DoseStatus.PENDING;

              return (
                <div 
                  key={dose.id} 
                  className={`bg-white border rounded-xl p-4 flex items-center justify-between shadow-sm transition-all ${isTaken ? 'opacity-70 border-emerald-100' : isMissed ? 'border-rose-100' : 'border-slate-200'}`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-full ${isTaken ? 'bg-emerald-50 text-emerald-600' : isMissed ? 'bg-rose-50 text-rose-600' : 'bg-slate-50 text-slate-400'}`}>
                      <Bell className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">{med?.name}</h3>
                      <p className="text-xs text-slate-500">{med?.dosage} • {new Date(dose.scheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {isPending ? (
                      <>
                        <button 
                          onClick={() => handleMarkDose(dose.id, DoseStatus.TAKEN)}
                          className="p-2 hover:bg-emerald-50 text-emerald-600 rounded-lg transition-colors border border-emerald-100"
                        >
                          <CheckCircle className="w-6 h-6" />
                        </button>
                        <button 
                          onClick={() => handleMarkDose(dose.id, DoseStatus.MISSED)}
                          className="p-2 hover:bg-rose-50 text-rose-600 rounded-lg transition-colors border border-rose-100"
                        >
                          <XCircle className="w-6 h-6" />
                        </button>
                      </>
                    ) : (
                      <span className={`text-xs font-bold uppercase tracking-wider ${isTaken ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {isTaken ? 'Taken' : 'Missed'}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* My Medications List */}
        <section className="space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Your Medications</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {medications.map(med => (
              <div key={med.id} className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-bold text-indigo-900">{med.name}</h3>
                    <p className="text-sm text-slate-600">{med.dosage}</p>
                  </div>
                  <div className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold">
                    {med.frequency}x daily
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-slate-50 flex justify-between items-center text-xs text-slate-500">
                  <span>Reminders: {med.reminderTimes.join(', ')}</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Add Med Modal */}
      {isAddingMed && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl animate-in fade-in zoom-in duration-200">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">New Medication</h2>
            <form onSubmit={handleAddMedication} className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Medicine Name</label>
                <input 
                  autoFocus
                  required
                  type="text" 
                  value={newMed.name}
                  onChange={e => setNewMed({...newMed, name: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                  placeholder="e.g. Aspirin"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Dosage</label>
                  <input 
                    required
                    type="text" 
                    value={newMed.dosage}
                    onChange={e => setNewMed({...newMed, dosage: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                    placeholder="e.g. 100mg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Doses Per Day</label>
                  <input 
                    required
                    type="number" 
                    min="1"
                    max="10"
                    value={newMed.frequency}
                    onChange={e => setNewMed({...newMed, frequency: parseInt(e.target.value) || 1})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                  />
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setIsAddingMed(false)}
                  className="flex-1 px-4 py-3 border border-slate-200 rounded-xl font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
                >
                  Save Medication
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
